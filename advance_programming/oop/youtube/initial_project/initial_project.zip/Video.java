import java.util.ArrayList;
import java.util.List;

public class Video {
    private final List<Comment> comments = new ArrayList<>();
    // TODO: Implement
}
