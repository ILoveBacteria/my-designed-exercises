import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class User {
    private final List<Video> videos = new ArrayList<>();
    // TODO: Implement
}
